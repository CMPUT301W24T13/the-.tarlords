package com.example.the_tarlords.data.Alert;

import java.util.ArrayList;

public interface AlertCallback {
    void onAlertsLoaded(ArrayList<Alert> alertList);
}

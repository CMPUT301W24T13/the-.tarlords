package com.example.the_tarlords.data.event;

/**
 * This class Handles event Poster
 * Private attribute that holds an image?
 */
public class EventPoster {


}

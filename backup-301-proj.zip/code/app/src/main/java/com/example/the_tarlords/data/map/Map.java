package com.example.the_tarlords.data.map;

public class Map {

}

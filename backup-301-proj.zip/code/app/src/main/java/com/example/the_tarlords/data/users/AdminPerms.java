package com.example.the_tarlords.data.users;

public interface AdminPerms {

}

package com.example.the_tarlords.placeholder;

public class Photo {
    public static Photo generateAutoProfilePhoto() {
        Photo photo = new Photo();
        return photo;
    }
    //TEMP CLASS TO AVOID JAVA ERROR MESSAGES ;-;
}
